#include <iostream>
#include <iomanip>
#include <algorithm>
#include "Polynomial.h"

using namespace std;

// Default constructor initializes empty polynomial
Polynomial::Polynomial() {}

// Destructor clears the vector 
Polynomial::~Polynomial() {
    terms.clear();
}

// Prompts user to enter number of terms, then inputs each term
void Polynomial::enterTerms() {
    int numTerms;
    cout << "Enter number of polynomial terms: ";
    cin >> numTerms;

    for (int i = 0; i < numTerms; ++i) {
        int coef, exp;
        cout << "Enter coefficient: ";
        cin >> coef;
        cout << "Enter exponent: ";
        cin >> exp;
        addTerm(coef, exp);
    }
    simplify();
}

// Adds a single term to the polynomial
void Polynomial::addTerm(int coefficient, int exponent) {
    terms.push_back({coefficient, exponent});
}

// Simplifies polynomial by combining like terms and sorting
void Polynomial::simplify() {
    sort(terms.begin(), terms.end(), [](auto& a, auto& b) {
        return a.exponent > b.exponent;
    });

    vector<Term> result;
    for (size_t i = 0; i < terms.size(); ++i) {
        if (!result.empty() && result.back().exponent == terms[i].exponent) {
            result.back().coefficient += terms[i].coefficient;
        } else {
            result.push_back(terms[i]);
        }
    }

    // Remove zero coefficient terms
    terms.clear();
    for (const auto& term : result) {
        if (term.coefficient != 0) terms.push_back(term);
    }
}

// Outputs the polynomial in readable form
void Polynomial::printPolynomial() const {
    if (terms.empty()) {
        cout << "0";
        return;
    }

    for (size_t i = 0; i < terms.size(); ++i) {
        if (i != 0 && terms[i].coefficient > 0) cout << " + ";
        else if (terms[i].coefficient < 0) cout << " - ";

        int absCoef = abs(terms[i].coefficient);
        if (absCoef != 1 || terms[i].exponent == 0)
            cout << absCoef;
        if (terms[i].exponent > 0) {
            cout << "x";
            if (terms[i].exponent > 1)
                cout << "^" << terms[i].exponent;
        }
    }
    cout << endl;
}

// Addition operator combines two polynomials
Polynomial Polynomial::operator+(const Polynomial& other) const {
    Polynomial result = *this;
    for (const auto& term : other.terms) {
        result.addTerm(term.coefficient, term.exponent);
    }
    result.simplify();
    return result;
}

// Subtraction operator subtracts another polynomial
Polynomial Polynomial::operator-(const Polynomial& other) const {
    Polynomial result = *this;
    for (const auto& term : other.terms) {
        result.addTerm(-term.coefficient, term.exponent);
    }
    result.simplify();
    return result;
}

// Assignment operator copies terms from another polynomial
Polynomial& Polynomial::operator=(const Polynomial& other) {
    if (this != &other) {
        terms = other.terms;
    }
    return *this;
}

// Addition assignment operator modifies current polynomial
Polynomial& Polynomial::operator+=(const Polynomial& other) {
    for (const auto& term : other.terms) {
        addTerm(term.coefficient, term.exponent);
    }
    simplify();
    return *this;
}

// Subtraction assignment operator modifies current polynomial
Polynomial& Polynomial::operator-=(const Polynomial& other) {
    for (const auto& term : other.terms) {
        addTerm(-term.coefficient, term.exponent);
    }
    simplify();
    return *this;
}
