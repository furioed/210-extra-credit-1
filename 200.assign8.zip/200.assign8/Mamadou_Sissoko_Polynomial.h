#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include <vector>

class Polynomial {
public:
    Polynomial();  // Default constructor
    ~Polynomial(); // Destructor
    void enterTerms(); // Input polynomial terms
    void printPolynomial() const; // Display polynomial

    // Operator overloads
    Polynomial operator+(const Polynomial&) const;
    Polynomial operator-(const Polynomial&) const;
    Polynomial& operator=(const Polynomial&);
    Polynomial& operator+=(const Polynomial&);
    Polynomial& operator-=(const Polynomial&);

private:
    struct Term {
        int coefficient;
        int exponent;
    };
    
    std::vector<Term> terms;

    void addTerm(int coefficient, int exponent);
    void simplify(); // Combine like terms and sort
};

#endif
